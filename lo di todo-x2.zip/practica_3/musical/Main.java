package musical;

public class Main {
    public static void main(String[] args) {
        InstrumentoMusical[] instrumentos = new InstrumentoMusical[2];

        instrumentos[0] = new Piano();
        instrumentos[1] = new Saxo();

        for (InstrumentoMusical instrumento : instrumentos) {
            instrumento.afinar();
            instrumento.tocar();
            System.out.println();
        }
    }
}