package musical;

interface InstrumentoMusical {
    void tocar();
    void afinar();
}

class Piano implements InstrumentoMusical {
    @Override
    public void tocar() {
        System.out.println("Tocando el piano con melodías suaves.");
    }

    @Override
    public void afinar() {
        System.out.println("Afinando el piano.");
    }
}

class Saxo implements InstrumentoMusical {
    @Override
    public void tocar() {
        System.out.println("Tocando el saxo con sonidos jazzísticos.");
    }

    @Override
    public void afinar() {
        System.out.println("Afinando el saxo.");
    }
}


