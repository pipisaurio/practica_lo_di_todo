package juescp;

interface EstrategiaPago {
    void procesarPago(double monto);
}