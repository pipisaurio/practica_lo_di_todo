package juescp;

class PagoTarjeta implements EstrategiaPago {
    @Override
    public void procesarPago(double monto) {
        System.out.println("Procesando pago de " + monto + " usando tarjeta de crédito.");
    }
}

class PagoPayPal implements EstrategiaPago {
    @Override
    public void procesarPago(double monto) {
        System.out.println("Procesando pago de " + monto + " usando PayPal.");
    }
}
