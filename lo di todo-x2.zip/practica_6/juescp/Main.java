package juescp;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        System.out.println("Seleccione la estrategia de pago:");
        System.out.println("1. Pago con tarjeta de crédito");
        System.out.println("2. Pago con PayPal");
        System.out.print("Ingrese su opción (1 o 2): ");
        int opcion = scanner.nextInt();

        EstrategiaPago estrategiaPago = null;
        switch (opcion) {
            case 1:
                estrategiaPago = new PagoTarjeta();
                break;
            case 2:
                estrategiaPago = new PagoPayPal();
                break;
            default:
                System.out.println("Opción inválida. Seleccionando pago con tarjeta de crédito por defecto.");
                estrategiaPago = new PagoTarjeta();
        }

        CarritoDeCompras carrito = new CarritoDeCompras(estrategiaPago);
        System.out.print("Ingrese el monto del pago: ");
        double monto = scanner.nextDouble();
        carrito.pagar(monto);
    }
}
