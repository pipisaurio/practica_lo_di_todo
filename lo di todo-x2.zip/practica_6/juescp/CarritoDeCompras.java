package juescp;

class CarritoDeCompras{
    private EstrategiaPago estrategiaPago;

    public CarritoDeCompras(EstrategiaPago estrategiaPago) {
        this.estrategiaPago = estrategiaPago;
    }

    public void pagar(double monto) {
        estrategiaPago.procesarPago(monto);
    }
}