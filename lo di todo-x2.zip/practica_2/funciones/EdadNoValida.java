package funciones;

public class EdadNoValida extends Exception {
    public EdadNoValida(String mensaje) {
        super(mensaje);
    }
}
