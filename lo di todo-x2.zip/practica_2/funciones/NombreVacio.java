package funciones;

public class NombreVacio extends Exception {
    public NombreVacio(String mensaje) {
        super(mensaje);
    }
}
