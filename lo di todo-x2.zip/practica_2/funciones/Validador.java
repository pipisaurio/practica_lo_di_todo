package funciones;
import java.util.regex.Pattern;

public class Validador {

    public void validarNombre(String nombre) throws NombreVacio {
        if (nombre == null || nombre.trim().isEmpty()) {
            throw new NombreVacio("El nombre no puede estar vacío.");
        }
        if (!nombre.matches("[a-zA-Z\\s]+")) {
            throw new NombreVacio("El nombre no puede contener números.");
        }
    }

    public void validarEdad(int edad) throws EdadNoValida {
        if (edad <= 0) {
            throw new EdadNoValida("La edad debe ser un número positivo.");
        }
    }

    public void validarCorreo(String correo) throws CorreoNoValido {
        String regex = "^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+$";
        Pattern pattern = Pattern.compile(regex);

        if (!pattern.matcher(correo).matches()) {
            throw new CorreoNoValido("El correo electrónico no tiene un formato válido.");
        }
    }
}

