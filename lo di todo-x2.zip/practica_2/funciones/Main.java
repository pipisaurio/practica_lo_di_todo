package funciones;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Validador validador = new Validador();

        try {
            System.out.print("Introduce tu nombre: ");
            String nombre = scanner.nextLine();
            validador.validarNombre(nombre);

            System.out.print("Introduce tu edad: ");
            int edad = scanner.nextInt();
            validador.validarEdad(edad);

            System.out.print("Introduce tu correo electrónico: ");
            String correo = scanner.next();
            validador.validarCorreo(correo);

            System.out.println("USTED SE REGISTRO");

        } catch (NombreVacio | EdadNoValida | CorreoNoValido e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
}
