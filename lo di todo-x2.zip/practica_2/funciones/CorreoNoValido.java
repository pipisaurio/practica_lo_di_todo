package funciones;

public class CorreoNoValido extends Exception {
    public CorreoNoValido(String mensaje) {
        super(mensaje);
    }
}
